<?php
session_start();

// Include database connection
include("dbconnect.php");

// Include email sending function
include("email.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['user_email'];

    // Check if the email already exists in the database
    $sql_check_email = "SELECT * FROM users WHERE user_email = ?";
    $stmt_check_email = $con->prepare($sql_check_email);
    $stmt_check_email->bind_param("s", $email);
    $stmt_check_email->execute();
    $result_check_email = $stmt_check_email->get_result();

    if ($result_check_email->num_rows > 0) {
        // Email exists, update OTP and send
        $otp = rand(100000, 999999); // Generate OTP

        // Update OTP in database
        $sql_update_otp = "UPDATE users SET user_otp = ? WHERE user_email = ?";
        $stmt_update_otp = $con->prepare($sql_update_otp);
        $stmt_update_otp->bind_param("ss", $otp, $email);
        $stmt_update_otp->execute();

        // Send OTP via email
        $subject = "OTP Verification";
        $message = "Your OTP for verification is: $otp";
        if (send_otp($email, $subject, $message)) {
            header("location: verify.php?msg=Please check your email for OTP and verify.");
            exit;
        } else {
            echo "Failed to send OTP. Please try again.";
        }
    } else {
        // Email does not exist, insert into database and send OTP
        $otp = rand(100000, 999999); // Generate OTP

        // Insert new email and OTP into database
        $sql_insert_email = "INSERT INTO users (user_email) VALUES ('$_POST[user_email]')";
        $stmt_insert_email = $con->prepare($sql_insert_email);
        $stmt_insert_email->bind_param("ss", $email, $otp);
        if ($stmt_insert_email->execute()) {
            // Send OTP via email
            $subject = "OTP Verification";
            $message = "Your OTP for verification is: $otp";
            if (send_otp($email, $subject, $message)) {
                header("location: verify.php?msg=Email ID stored. Please check your email for OTP and verify.");
                exit;
            } else {
                echo "Failed to send OTP. Please try again.";
            }
        } else {
            echo "Failed to store email ID. Please try again.";
        }
    }

    // Close prepared statements and database connection
    $stmt_check_email->close();
    $stmt_update_otp->close();
    $stmt_insert_email->close();
    $con->close();
}
?>
