<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';

//if (isset($_REQUEST['to'])) {
//    $to = $_REQUEST['to'];
//    $subject = $_REQUEST['subject'];
//    $content = $_REQUEST['message'];
//    send_email($to, $subject, $content);
//}

function send_otp($to, $subject, $content) {

//Load Composer's autoloader
//Create an instance; passing `true` enables exceptions
    $mail = new PHPMailer(true);

    try {                      //Enable verbose debug output
        $mail->isSMTP();                                            //Send using SMTP
        $mail->Host = 'smtp.gmail.com';                     //Set the SMTP server to send through
        $mail->SMTPAuth = true;                                   //Enable SMTP authentication
        $mail->Username = 'dharmikdonda2206@gmail.com';                     //SMTP username
        $mail->Password = 'mrbg hyyu lnvc uaqm';                               //SMTP password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
        $mail->Port = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`
        //Recipients
        $mail->setFrom('dharmikdonda2206@email.com', 'Hopeful hearts');
        $mail->addAddress($to, "verify Email");     //Add a recipient

        $mail->isHTML(true);                                  //Set email format to HTML
        $mail->Subject = $subject;
        $mail->Body = "<font color='green' size='5'> your otp is :" . $content . "<br>This is work one time.</br></font>";
        $mail->send();
        echo 'otp has been sent successfully';
        return true;
    } catch (Exception $e) {
        echo "OTP Could not be sent Mailer Error: {$mail->ErrorInfo}";
    }
}
